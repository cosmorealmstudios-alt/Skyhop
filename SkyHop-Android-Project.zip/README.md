# SkyHop Android Game

A portrait endless-flap arcade game packaged as an Android WebView app.

## Features
- Responsive canvas graphics, layered sky, parallax clouds and animated scenery
- Animated bird, polished start/game-over/pause screens, score and local best score
- Procedural sound effects with mute control
- Touch, mouse, Space, W and Up Arrow controls
- No network access required at runtime

## Build an APK
1. Install Android Studio (including Android SDK Platform 35 and a compatible JDK).
2. Open this folder in Android Studio and allow Gradle sync.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK output is usually `app/build/outputs/apk/debug/app-debug.apk`.

Or from a terminal with Android SDK configured:
`gradle assembleDebug`

This environment did not have Android SDK/Gradle installed, so the APK could not be compiled here. The complete Android Studio project and playable HTML game are included.
